import React, { useState } from "react";
import "./sidebar.css";
import { useHistory } from "react-router-dom";
const Sidebar = () => {
  const launchYear = [
    "2006",
    "2007",
    "2008",
    "2009",
    "2010",
    "2011",
    "2012",
    "2013",
    "2014",
    "2015",
    "2016",
    "2017",
    "2018",
    "2019",
    "2020",
  ];
  const history = useHistory();

  const handleClick = (year) => {
    console.log(year);

    history.push("/" + year);
  };
  const booleanFilters = ["True", "False"];
  const filterBtnItems = launchYear.map((year, index) => (
    <button
      type="button"
      onClick={() => handleClick(year)}
      key={index}
      className="btn-primary"
    >
      {year}
    </button>
  ));
  const successfulLaunch = booleanFilters.map((bool, index) => (
    <button type="button" key={index} className="btn-primary">
      {bool}
    </button>
  ));
  const successfulLaing = booleanFilters.map((bool, index) => (
    <button type="button" key={index} className="btn-primary">
      {bool}
    </button>
  ));
  return (
    <aside>
      <h3>Filters</h3>
      <div className="launch-year-filter">
        <h5>Launch year</h5>
        <div className="filterBtns">{filterBtnItems}</div>
      </div>
      <div className="launch-year-filter">
        <h5>Successful Launch</h5>
        <div className="filterBtns">{successfulLaunch}</div>
      </div>
      <div className="launch-year-filter">
        <h5>Successful Launch</h5>
        <div className="filterBtns">{successfulLaing}</div>
      </div>
    </aside>
  );
};
export default Sidebar;

import React from "react";
import Sidebar from "./sidebar/Sidebar";
import ListContent from "./section/ListContent";
import "./mainComponent.css";
import { BrowserRouter, Redirect, Switch, Route } from "react-router-dom";

const MainComponent = () => {
  return (
    <div className="wrapper">
      <BrowserRouter>
        <Switch>
          <Route path="/" exact>
            <Sidebar />
            <ListContent year={null} />
          </Route>

          <Route path="/:launch_year">
            <Sidebar />
            <ListContent year={"2016"} />
          </Route>
          <Redirect to="/" />
        </Switch>
      </BrowserRouter>
    </div>
  );
};
export default MainComponent;

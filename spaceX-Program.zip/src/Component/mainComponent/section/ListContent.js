import React from "react";
import List from "./List";

const ListContent = (props) => {
  return <List year={props.year} />;
};
export default ListContent;

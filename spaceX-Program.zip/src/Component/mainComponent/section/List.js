import React, { useEffect, useState } from "react";
import axios from "axios";
import "./list.css";

const List = () => {
  const [itemList, setItemList] = useState([]);

  useEffect(() => {
    async function fetchData() {
      const requests = await axios.get(
        "https://api.spaceXdata.com/v3/launches?limit=100"
      );

      console.log(requests.data);
      setItemList(requests.data);

      return requests;
    }

    fetchData();
  }, []);

  console.log(itemList);
  return (
    <div className="item-list-wrapper">
      {itemList.map((items, index) => (
        <div className="items-box" key={index}>
          <img src={items.links.mission_patch_small} alt={items.mission_name} />
          <h3>
            {items.mission_name} #{items.flight_number}
          </h3>
          <label>Mission Ids</label>
          <ul>
            <li>{items.launch_site.site_id}</li>
          </ul>
          <div className="list-element">
            <label>
              Launch Year : <span>{items.launch_year}</span>
            </label>
          </div>
          <div className="list-element">
            <label>
              Successful Launch: <span>{String(items.launch_success)}</span>
            </label>
          </div>
          <div className="list-element">
            <label>
              Successful Landing : <span>{items.launch_site.site_name}</span>
            </label>
          </div>
        </div>
      ))}
    </div>
  );
};
export default List;

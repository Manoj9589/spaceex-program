import React from 'react';
import './footer.css';
const Footer = () => {
	return <div className="footer"><h1>Developed by <b>Manoj Sharma</b></h1></div>
}
export default Footer
import React from 'react';
import './header.css';

const Header = () => {
	return <h1 className="heading">SpaceEx Launch Program</h1>
}
export default Header